package argo.jdom;

interface JsonListenerToJdomAdapter_NodeContainer
{
    public abstract void addNode(JsonNodeBuilder jsonnodebuilder);

    public abstract void addField(JsonFieldBuilder jsonfieldbuilder);
}
