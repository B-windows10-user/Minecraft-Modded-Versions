package argo.jdom;

public interface JsonNodeBuilder
{
    public abstract JsonNode buildNode();
}
