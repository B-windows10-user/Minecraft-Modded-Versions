package argo.saj;

interface ThingWithPosition
{
    public abstract int getColumn();

    public abstract int getRow();
}
