package net.minecraft.src;

public class BlockNetherrack extends Block
{
    public BlockNetherrack(int par1, int par2)
    {
        super(par1, par2, Material.rock);
        func_56773_a(CreativeTabs.field_57050_b);
    }
}
