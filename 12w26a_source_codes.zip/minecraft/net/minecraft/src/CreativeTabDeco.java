package net.minecraft.src;

final class CreativeTabDeco extends CreativeTabs
{
    CreativeTabDeco(int par1, String par2Str)
    {
        super(par1, par2Str);
    }

    public int func_57042_a()
    {
        return Block.plantRed.blockID;
    }
}
