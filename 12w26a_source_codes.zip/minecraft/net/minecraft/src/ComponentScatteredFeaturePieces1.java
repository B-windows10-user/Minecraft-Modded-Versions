package net.minecraft.src;

public class ComponentScatteredFeaturePieces1
{
    public ComponentScatteredFeaturePieces1()
    {
    }
}
