package net.minecraft.src;

import java.util.List;

public class BiomeGenOcean extends BiomeGenBase
{
    public BiomeGenOcean(int par1)
    {
        super(par1);
        spawnableCreatureList.clear();
    }
}
