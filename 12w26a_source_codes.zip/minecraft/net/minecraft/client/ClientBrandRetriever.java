package net.minecraft.client;

public class ClientBrandRetriever
{
    public ClientBrandRetriever()
    {
    }

    public static String func_56462_getClientModName()
    {
        return "vanilla";
    }
}
